# ScentStation Backend — Task Package 1 (Runnable Project)

Multi-Brand IoT Perfume Experience and Management Platform (Chanel, YSL, Dior, Gucci, Hermès).

## 1. Cấu trúc thư mục
```text
ScentStation_Backend/
├── app/
│   ├── main.py              # FastAPI app entrypoint
│   ├── core/
│   │   ├── config.py        # Cấu hình DB & JWT
│   │   ├── database.py      # SQLAlchemy engine & session
│   │   └── security.py      # Bcrypt password hashing & JWT
│   ├── models/models.py     # ORM Models (Tenant, Account, Role, Permission, Brand, Perfume, Machine, PerfumeSlot, AuditLog)
│   ├── schemas/schemas.py   # Pydantic Request/Response DTOs
│   └── api/
│       ├── deps.py          # Dependency xác thực JWT, RBAC & Tenant Scope
│       └── v1/
│           ├── auth.py      # Login & /me
│           ├── tenants.py   # Quản lý Tenant (Super Admin)
│           ├── brands.py    # Quản lý Brand & Perfume (Cách ly theo Tenant)
│           └── users.py     # Quản lý User & Role/Permission
├── tests/
│   └── test_scentstation.py # Automated tests (Auth, RBAC, Tenant Isolation)
├── seed.py                  # Tạo dữ liệu mẫu (5 thương hiệu & tài khoản test)
├── requirements.txt
└── .env.example
```

## 2. Hướng dẫn chạy nhanh trên VS Code

### Bước 1: Mở thư mục bằng VS Code & tạo môi trường ảo
```bash
python -m venv .venv
# Windows (PowerShell):
.venv\Scripts\Activate.ps1
# macOS / Linux:
source .venv/bin/activate
```

### Bước 2: Cài đặt thư viện
```bash
pip install -r requirements.txt
```

### Bước 3: Khởi tạo dữ liệu mẫu (Seed Data)
```bash
python seed.py
```
Dữ liệu mẫu sẽ tạo sẵn:
- **Super Admin:** `superadmin@scentstation.io` / `Admin123!`
- **Tenant 1 (Chanel Ops — Chanel):** `manager@chanel.com` / `Pass123!` và `tech@chanel.com` / `Pass123!`
- **Tenant 2 (LVMH Ops — Dior, YSL):** `manager@lvmh.com` / `Pass123!`
- **Tenant 3 (Kering & Hermès Ops — Gucci, Hermès):** `manager@luxury.com` / `Pass123!`

### Bước 4: Chạy API Server
```bash
uvicorn app.main:app --reload
```
Mở trình duyệt vào **Swagger UI** để test trực tiếp:
👉 `http://127.0.0.1:8000/docs`

### Bước 5: Chạy Automated Tests (Kiểm tra Auth, RBAC & Tenant Isolation)
```bash
pytest -v
```
