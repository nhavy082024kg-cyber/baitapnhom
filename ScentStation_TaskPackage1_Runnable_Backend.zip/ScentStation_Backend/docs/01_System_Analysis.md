# Document 01: System Analysis — ScentStation Platform

## 1. Project Overview
**ScentStation** is a multi-brand IoT perfume experience and management platform. Deployed via physical smart kiosks in retail spaces, malls, and airports, each kiosk houses five independent perfume spray slots mapped to premier luxury brands (**Chanel, YSL, Dior, Gucci, and Hermès**). The platform enables customers to sample fragrances on-demand via QR code payments while providing brand operators and system administrators with a centralized, multi-tenant cloud dashboard to monitor telemetry, manage inventory, configure slots, and dispatch maintenance tickets.

## 2. Project Goals
* **Seamless Customer Experience:** Provide an intuitive, contactless kiosk workflow allowing customers to select a fragrance, pay via QR code, and trigger a precise spray session.
* **Strict Multi-Tenant Isolation:** Ensure that multiple perfume brand operators share the underlying cloud infrastructure and physical kiosks while keeping each tenant's operational, financial, and inventory data strictly isolated.
* **Real-Time IoT Monitoring & Alerting:** Track device connectivity, spray counts, and estimated perfume levels via MQTT telemetry, generating automated low-inventory or hardware fault alerts.
* **Role-Based Access Control (RBAC):** Enforce granular permissions across Super Admins, Tenant/Brand Managers, and Field Technicians.

## 3. Project Scope
### In-Scope (Task Package 1)
* Multi-tenant architecture design and tenant-scoped data isolation.
* Relational database design (ERD, tables, constraints) supporting tenants, users, roles, brands, perfumes, kiosks, slots, transactions, and maintenance.
* Authentication (JWT) and Role-Based Access Control (RBAC).
* Brand and Tenant Administration APIs (CRUD for brands, perfumes, users, and role permissions).
* Backend implementation using Python (FastAPI), PostgreSQL, and SQLAlchemy, accompanied by automated isolation and authorization tests.

### Out-of-Scope
* Physical hardware wiring, microcontroller firmware (ESP32/STM32), and physical actuator calibration.
* Direct processing or storage of customer credit card credentials (delegated to third-party QR payment gateways).

## 4. System Actors
| Actor | Role Scope | Primary Responsibilities |
| :--- | :--- | :--- |
| **System Super Admin** | Platform-wide | Onboards new tenants, provisions kiosks, manages global system health, and oversees cross-tenant infrastructure. |
| **Brand / Tenant Manager** | Tenant-scoped | Manages their brand's perfume catalog, views sales/transactions, monitors slot inventory levels, and assigns brand staff. |
| **Field Technician** | Assigned Kiosks | Views hardware alerts, executes maintenance tickets, refills perfume cartridges, and logs maintenance outcomes. |
| **Kiosk IoT Client** | Device-scoped | Authenticates via device credentials, requests QR payment links, reports spray session execution, and publishes telemetry. |
| **End Customer** | Physical Kiosk | Interacts with the kiosk touchscreen to browse the 5 scents, scans QR to pay, and receives the fragrance spray. |

## 5. Business Rules
* **BR-01 (Five-Slot Kiosk Constraint):** Every registered kiosk machine contains exactly five independent perfume slots (`slot_number` 1 through 5).
* **BR-02 (Tenant Data Isolation):** Every tenant-owned record (brands, perfumes, transactions, alerts) must be bound to a `tenant_id`. Queries executed by a tenant user must automatically filter by their authenticated `tenant_id`.
* **BR-03 (Payment-Before-Spray):** A `SpraySession` can only be authorized and executed after the associated `Transaction` has a confirmed `Payment` status from the QR payment provider.
* **BR-04 (Inventory Estimation):** Remaining perfume volume is calculated dynamically based on initial cartridge volume minus cumulative authorized spray events.
* **BR-05 (Auditability):** All administrative mutations (role changes, slot deactivations, tenant creation) must generate an immutable `AuditLog` entry.

## 6. Functional Requirements (FR)
* **FR-01 Authentication & Session Management:** Users shall log in using email and password to receive a signed JWT containing `account_id`, `tenant_id`, and `roles`.
* **FR-02 Multi-Tenant Brand & Perfume Management:** Tenant Managers shall create, update, and deactivate perfumes under their assigned brand(s).
* **FR-03 User & RBAC Administration:** Admins shall create user accounts within their tenant and assign roles mapped to granular permissions.
* **FR-04 Kiosk & Slot Configuration:** Authorized operators shall view kiosk status and map specific perfumes to slots 1–5.
* **FR-05 QR Payment & Spray Authorization:** The system shall generate a unique transaction reference for a selected slot, verify payment webhook confirmation, and authorize a single spray session.
* **FR-06 Telemetry, Inventory & Maintenance:** The system shall ingest telemetry, trigger low-level alerts, and allow creation/resolution of maintenance tickets.

## 7. Non-Functional Requirements (NFR)
* **NFR-01 Security & Isolation:** Passwords must be hashed using `bcrypt` or `Argon2`. Cross-tenant data leakage must be prevented at both the API dependency layer and ORM query layer.
* **NFR-02 Performance:** Standard REST API endpoints must respond within `< 200ms` under normal load; QR payment authorization callbacks must process within `< 500ms`.
* **NFR-03 Reliability & Idempotency:** Payment webhooks and spray session reports must use unique idempotency keys to prevent duplicate charges or double sprays.
* **NFR-04 Maintainability:** Clean modular architecture separating routers (controllers), services (business logic), repositories (data access), and schemas (Pydantic DTOs).

## 8. System Constraints and Assumptions
* **Technology Stack:** Python 3.11+, FastAPI, PostgreSQL 15+, SQLAlchemy 2.0, Pydantic v2, PyJWT, Passlib (bcrypt).
* **Prototype Brand Mapping:** The initial deployment maps slots 1–5 to Chanel, YSL, Dior, Gucci, and Hermès respectively.
* **Estimated Inventory:** Unless calibrated optical/weight sensors are attached, remaining perfume quantity is a software estimate derived from spray count.
