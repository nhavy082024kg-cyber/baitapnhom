# Document 06: Testing & Multi-Tenant Isolation Verification

## 1. Test Objectives
Verify that:
1. Users can authenticate with valid credentials and receive a tenant-scoped JWT.
2. Users lacking `BRAND_MANAGER` privileges receive `403 Forbidden` when attempting administrative mutations.
3. **Tenant Isolation:** A manager from Tenant A (e.g., Chanel) cannot list, view, or add perfumes to a brand owned by Tenant B (e.g., Dior/YSL/Gucci/Hermès).

## 2. Automated Test Suite (`test_isolation.py`)
Run using `pytest`:
```python
from fastapi.testclient import TestClient
from main import app, SessionLocal, Tenant, Account, Brand, pwd_context

client = TestClient(app)

def setup_seed_data():
    db = SessionLocal()
    if not db.query(Tenant).first():
        t1 = Tenant(tenant_code="CHANEL_OPS", tenant_name="Chanel Operator")
        t2 = Tenant(tenant_code="LVMH_OPS", tenant_name="Dior & YSL Operator")
        db.add_all([t1, t2])
        db.commit()

        u1 = Account(tenant_id=t1.tenant_id, email="admin@chanel.com", password_hash=pwd_context.hash("Pass123!"), full_name="Chanel Mgr", role_name="BRAND_MANAGER")
        u2 = Account(tenant_id=t2.tenant_id, email="admin@dior.com", password_hash=pwd_context.hash("Pass123!"), full_name="Dior Mgr", role_name="BRAND_MANAGER")
        u3 = Account(tenant_id=t1.tenant_id, email="tech@chanel.com", password_hash=pwd_context.hash("Pass123!"), full_name="Tech Staff", role_name="TECHNICIAN")
        db.add_all([u1, u2, u3])
        db.commit()
    db.close()

def get_token(email: str, password: str) -> str:
    res = client.post("/api/v1/auth/login", data={"username": email, "password": password})
    assert res.status_code == 200
    return res.json()["access_token"]

def test_multi_tenant_isolation_and_rbac():
    setup_seed_data()
    chanel_token = get_token("admin@chanel.com", "Pass123!")
    dior_token = get_token("admin@dior.com", "Pass123!")
    tech_token = get_token("tech@chanel.com", "Pass123!")

    # 1. RBAC check: Technician cannot create a brand
    r_forbidden = client.post("/api/v1/brands", json={"brand_name": "Chanel"}, headers={"Authorization": f"Bearer {tech_token}"})
    assert r_forbidden.status_code == 403

    # 2. Chanel Manager creates Chanel brand
    r_chanel = client.post("/api/v1/brands", json={"brand_name": "Chanel"}, headers={"Authorization": f"Bearer {chanel_token}"})
    assert r_chanel.status_code == 201
    chanel_brand_id = r_chanel.json()["brand_id"]

    # 3. Dior Manager creates Dior & YSL brands
    r_dior = client.post("/api/v1/brands", json={"brand_name": "Dior"}, headers={"Authorization": f"Bearer {dior_token}"})
    assert r_dior.status_code == 201

    # 4. Isolation Check: Dior Manager cannot see Chanel brand
    dior_brands = client.get("/api/v1/brands", headers={"Authorization": f"Bearer {dior_token}"}).json()
    brand_names = [b["brand_name"] for b in dior_brands]
    assert "Dior" in brand_names
    assert "Chanel" not in brand_names

    # 5. Cross-Tenant Write Block: Dior Manager cannot add perfume to Chanel's brand_id
    r_attack = client.post(
        f"/api/v1/brands/{chanel_brand_id}/perfumes",
        json={"product_code": "HACK-01", "perfume_name": "Unauthorized Scent"},
        headers={"Authorization": f"Bearer {dior_token}"}
    )
    assert r_attack.status_code == 404
```
