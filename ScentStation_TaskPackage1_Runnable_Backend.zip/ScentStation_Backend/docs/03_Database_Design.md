# Document 03: Database Design

## 1. Entity-Relationship Overview (ERD)
```text
[tenants] 1 ──── * [accounts] * ──── * [roles] * ──── * [permissions]
    │
    ├──── * [brands] 1 ──── * [perfumes]
    │
    └──── * [machines] 1 ──── 5 [perfume_slots]
                                      │
                                      └──── * [transactions] 1 ──── 1 [payments]
                                                    │
                                                    └──── 1 [spray_sessions]
```

## 2. Table Specifications

### 2.1 `tenants`
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `tenant_id` | UUID / SERIAL | PK | Unique tenant identifier |
| `tenant_code` | VARCHAR(50) | UNIQUE, NOT NULL | Short code (e.g., `CHANEL_VN`, `LVMH_GROUP`) |
| `tenant_name` | VARCHAR(150) | NOT NULL | Legal/display name of the operator |
| `status` | VARCHAR(20) | DEFAULT 'ACTIVE' | `ACTIVE`, `SUSPENDED` |
| `created_at` | TIMESTAMP | DEFAULT NOW() | Creation timestamp |

### 2.2 `accounts`
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `account_id` | SERIAL | PK | Unique user ID |
| `tenant_id` | INT | FK -> `tenants.tenant_id`, NOT NULL | Tenant ownership scope |
| `email` | VARCHAR(150) | UNIQUE, NOT NULL | Login email |
| `password_hash` | VARCHAR(255) | NOT NULL | Bcrypt password hash |
| `full_name` | VARCHAR(100) | NOT NULL | Operator full name |
| `is_super_admin` | BOOLEAN | DEFAULT FALSE | True for platform-wide administrators |
| `status` | VARCHAR(20) | DEFAULT 'ACTIVE' | `ACTIVE`, `DISABLED` |

### 2.3 `roles` & `permissions` (RBAC)
* **`roles`**: `role_id` (PK), `role_name` (UNIQUE: `SUPER_ADMIN`, `BRAND_MANAGER`, `TECHNICIAN`), `description`.
* **`permissions`**: `permission_id` (PK), `permission_code` (UNIQUE: `BRAND_WRITE`, `PERFUME_WRITE`, `USER_MANAGE`, `SLOT_CONFIG`), `module`.
* **`account_roles`**: `account_id` (FK), `role_id` (FK) — Composite PK.
* **`role_permissions`**: `role_id` (FK), `permission_id` (FK) — Composite PK.

### 2.4 `brands` & `perfumes`
* **`brands`**: `brand_id` (PK), `tenant_id` (FK -> `tenants`), `brand_name` (NOT NULL: Chanel, YSL, Dior, Gucci, Hermès), `status`.
* **`perfumes`**: `perfume_id` (PK), `brand_id` (FK -> `brands`), `tenant_id` (FK -> `tenants`), `product_code` (UNIQUE), `perfume_name`, `price_per_spray` (NUMERIC(10,2)), `status`.

### 2.5 `machines` & `perfume_slots`
* **`machines`**: `machine_id` (PK), `tenant_id` (FK -> `tenants`), `machine_code` (UNIQUE), `location`, `status`, `last_seen_at`.
* **`perfume_slots`**: `slot_id` (PK), `machine_id` (FK -> `machines`), `slot_number` (INT, CHECK `slot_number BETWEEN 1 AND 5`), `brand_id` (FK -> `brands`), `perfume_id` (FK -> `perfumes`), `remaining_ml` (NUMERIC), `status`.
  * **Unique Constraint:** `UNIQUE(machine_id, slot_number)` ensures each kiosk has at most 5 distinct slots numbered 1 to 5.

## 3. Integrity & Isolation Constraints
1. **Cross-Tenant Foreign Key Alignment:** A `perfume` record's `tenant_id` must match its parent `brand.tenant_id`.
2. **Slot Uniqueness:** `(machine_id, slot_number)` is strictly unique and bounded between 1 and 5.
3. **Soft Deletion:** Critical entities (`tenants`, `brands`, `perfumes`, `accounts`) use a `status` flag (`ACTIVE` / `INACTIVE`) rather than hard `DELETE` to preserve financial and audit history.
