# Document 02: Multi-Tenant Architecture & System Design

## 1. Multi-Tenant Strategy
ScentStation adopts a **Shared Database, Shared Schema (Discriminator Column)** multi-tenancy model:
* **Tenant Discriminator (`tenant_id`):** Core tables (`accounts`, `brands`, `machines`, `audit_logs`, etc.) include a non-nullable `tenant_id` foreign key referencing `tenants(tenant_id)`.
* **Application-Level Enforcement:** FastAPI dependency injection extracts the `TenantContext` from the verified JWT token on every request and injects it into the service/repository layer, guaranteeing that Tenant A can never query or mutate Tenant B's records.

## 2. High-Level System Architecture
```
+-------------------+       HTTPS / REST (JWT)       +-----------------------+
|  Admin Dashboard  | <----------------------------> |                       |
+-------------------+                                |   FastAPI Backend     |
                                                     |  (Auth, RBAC, Brand,  |
+-------------------+       HTTPS / Webhooks         |   Kiosk, Billing)     |
|  Kiosk Touchscreen| <----------------------------> |                       |
+-------------------+                                +-----------+-----------+
                                                                 |
+-------------------+       MQTT / TLS Telemetry                 | SQLAlchemy ORM
| Kiosk IoT Firmware| -------------------------------------------+
+-------------------+                                            v
                                                     +-----------------------+
                                                     |   PostgreSQL DB       |
                                                     | (Tenant-Scoped Data)  |
                                                     +-----------------------+
```

## 3. Package & Directory Structure (Python / FastAPI)
```text
scentstation_backend/
├── app/
│   ├── main.py                 # FastAPI application entrypoint
│   ├── core/
│   │   ├── config.py           # Environment variables & settings
│   │   ├── database.py         # SQLAlchemy engine & session factory
│   │   └── security.py         # JWT creation/verification & bcrypt hashing
│   ├── models/                 # SQLAlchemy ORM models
│   ├── schemas/                # Pydantic Request/Response DTOs
│   ├── api/
│   │   ├── deps.py             # Auth, RBAC, and TenantContext dependencies
│   │   └── v1/
│   │       ├── auth.py         # Login & token endpoints
│   │       ├── tenants.py      # Super Admin tenant management
│   │       ├── brands.py       # Brand & perfume catalog endpoints
│   │       └── users.py        # Tenant user & role assignment endpoints
│   └── services/               # Business logic & audit logging
├── tests/                      # Pytest suite (Auth, RBAC, Tenant Isolation)
└── requirements.txt
```
