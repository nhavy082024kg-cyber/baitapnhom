# Document 05: Brand Administration & Python Backend Code

## 1. Brand Administration Endpoints
* `POST /api/v1/tenants` — Create a new tenant (Super Admin only).
* `GET /api/v1/brands` — List all brands belonging to the authenticated `tenant_id`.
* `POST /api/v1/brands` — Register a new brand under the current tenant (requires `BRAND_WRITE`).
* `POST /api/v1/brands/{brand_id}/perfumes` — Add a perfume to a brand (verifies `brand.tenant_id == current_user.tenant_id`).
* `GET /api/v1/perfumes` — List tenant-scoped perfumes.
* `POST /api/v1/users` — Create a new user within the current tenant and assign a role (requires `USER_MANAGE`).

## 2. Runnable Python Backend (`main.py`)
Below is a self-contained, runnable FastAPI + SQLAlchemy implementation (using SQLite in-memory/file by default for instant VS Code execution, and easily switched to PostgreSQL via `DATABASE_URL`).

```python
# Save as main.py and run: uvicorn main:app --reload
import os
from datetime import datetime, timedelta, timezone
from typing import List, Optional
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel, EmailStr
from sqlalchemy import create_engine, Column, Integer, String, Boolean, ForeignKey, Numeric, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker, Session, relationship
from passlib.context import CryptContext
import jwt

# --- CONFIGURATION ---
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./scentstation.db")
SECRET_KEY = os.getenv("SECRET_KEY", "super-secret-scentstation-key-2026")
ALGORITHM = "HS256"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")

# --- DATABASE MODELS ---
class Tenant(Base):
    __tablename__ = "tenants"
    tenant_id = Column(Integer, primary_key=True, index=True)
    tenant_code = Column(String(50), unique=True, nullable=False)
    tenant_name = Column(String(150), nullable=False)
    status = Column(String(20), default="ACTIVE")

class Account(Base):
    __tablename__ = "accounts"
    account_id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(Integer, ForeignKey("tenants.tenant_id"), nullable=False)
    email = Column(String(150), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(100), nullable=False)
    role_name = Column(String(50), default="BRAND_MANAGER")
    is_super_admin = Column(Boolean, default=False)
    status = Column(String(20), default="ACTIVE")

class Brand(Base):
    __tablename__ = "brands"
    brand_id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(Integer, ForeignKey("tenants.tenant_id"), nullable=False, index=True)
    brand_name = Column(String(100), nullable=False)
    status = Column(String(20), default="ACTIVE")
    perfumes = relationship("Perfume", back_populates="brand")

class Perfume(Base):
    __tablename__ = "perfumes"
    perfume_id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(Integer, ForeignKey("tenants.tenant_id"), nullable=False, index=True)
    brand_id = Column(Integer, ForeignKey("brands.brand_id"), nullable=False)
    product_code = Column(String(50), unique=True, nullable=False)
    perfume_name = Column(String(150), nullable=False)
    price_per_spray = Column(Numeric(10, 2), default=2.50)
    status = Column(String(20), default="ACTIVE")
    brand = relationship("Brand", back_populates="perfumes")

Base.metadata.create_all(bind=engine)

# --- SCHEMAS ---
class BrandCreate(BaseModel):
    brand_name: str

class BrandOut(BaseModel):
    brand_id: int
    tenant_id: int
    brand_name: str
    status: str
    class Config:
        from_attributes = True

class PerfumeCreate(BaseModel):
    product_code: str
    perfume_name: str
    price_per_spray: float = 2.50

class PerfumeOut(BaseModel):
    perfume_id: int
    tenant_id: int
    brand_id: int
    product_code: str
    perfume_name: str
    price_per_spray: float
    class Config:
        from_attributes = True

# --- DEPENDENCIES ---
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def create_access_token(data: dict):
    to_encode = data.copy()
    to_encode["exp"] = datetime.now(timezone.utc) + timedelta(hours=2)
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> Account:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if not email:
            raise HTTPException(status_code=401, detail="Invalid token")
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Could not validate credentials")
    user = db.query(Account).filter(Account.email == email, Account.status == "ACTIVE").first()
    if not user:
        raise HTTPException(status_code=401, detail="User inactive or not found")
    return user

def require_manager(user: Account = Depends(get_current_user)) -> Account:
    if not user.is_super_admin and user.role_name != "BRAND_MANAGER":
        raise HTTPException(status_code=403, detail="Insufficient role permissions")
    return user

# --- FASTAPI APP ---
app = FastAPI(title="ScentStation Multi-Tenant API", version="1.0.0")

@app.post("/api/v1/auth/login")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(Account).filter(Account.email == form_data.username).first()
    if not user or not pwd_context.verify(form_data.password, user.password_hash):
        raise HTTPException(status_code=400, detail="Incorrect email or password")
    token = create_access_token({"sub": user.email, "tenant_id": user.tenant_id, "role": user.role_name})
    return {"access_token": token, "token_type": "bearer", "tenant_id": user.tenant_id}

@app.get("/api/v1/brands", response_model=List[BrandOut])
def list_brands(current_user: Account = Depends(get_current_user), db: Session = Depends(get_db)):
    # Strict multi-tenant isolation
    return db.query(Brand).filter(Brand.tenant_id == current_user.tenant_id).all()

@app.post("/api/v1/brands", response_model=BrandOut, status_code=201)
def create_brand(payload: BrandCreate, current_user: Account = Depends(require_manager), db: Session = Depends(get_db)):
    brand = Brand(tenant_id=current_user.tenant_id, brand_name=payload.brand_name)
    db.add(brand)
    db.commit()
    db.refresh(brand)
    return brand

@app.post("/api/v1/brands/{brand_id}/perfumes", response_model=PerfumeOut, status_code=201)
def add_perfume(brand_id: int, payload: PerfumeCreate, current_user: Account = Depends(require_manager), db: Session = Depends(get_db)):
    brand = db.query(Brand).filter(Brand.brand_id == brand_id, Brand.tenant_id == current_user.tenant_id).first()
    if not brand:
        raise HTTPException(status_code=404, detail="Brand not found in your tenant scope")
    perfume = Perfume(
        tenant_id=current_user.tenant_id,
        brand_id=brand.brand_id,
        product_code=payload.product_code,
        perfume_name=payload.perfume_name,
        price_per_spray=payload.price_per_spray
    )
    db.add(perfume)
    db.commit()
    db.refresh(perfume)
    return perfume
```
