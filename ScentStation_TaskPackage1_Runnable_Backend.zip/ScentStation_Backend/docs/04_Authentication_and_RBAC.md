# Document 04: Authentication & RBAC Design

## 1. Authentication Flow (JWT)
1. **Login Request:** Client sends `POST /api/v1/auth/login` with `{ "email": "...", "password": "..." }`.
2. **Credential Verification:** Server fetches `Account` by email, verifies `status == 'ACTIVE'`, and checks `bcrypt.verify(plain_password, account.password_hash)`.
3. **Token Issuance:** Server signs an Access Token (HS256, 60-minute expiry) containing:
   ```json
   {
     "sub": "101",
     "email": "manager@chanel.com",
     "tenant_id": 1,
     "is_super_admin": false,
     "roles": ["BRAND_MANAGER"],
     "permissions": ["BRAND_READ", "PERFUME_WRITE", "USER_MANAGE"],
     "exp": 1795500000
   }
   ```

## 2. Authorization & Multi-Tenant Enforcement (RBAC)
Every protected endpoint uses chained FastAPI dependencies:
* **`get_current_user`:** Decodes and validates the Bearer JWT. Raises `401 Unauthorized` if invalid or expired.
* **`require_permission(perm_code)`:** Checks whether `perm_code` exists in the user's JWT permissions (or if `is_super_admin == True`). Raises `403 Forbidden` otherwise.
* **`get_tenant_scope`:** Returns the `tenant_id` of the authenticated user. Super Admins may optionally pass an `X-Tenant-ID` header to inspect a specific tenant, whereas regular tenant users are locked to their token's `tenant_id`.

## 3. Permission Matrix
| Permission Code | Super Admin | Brand Manager | Technician |
| :--- | :---: | :---: | :---: |
| `TENANT_MANAGE` | Yes | No | No |
| `BRAND_WRITE` | Yes | Yes (Own Tenant) | No |
| `PERFUME_WRITE` | Yes | Yes (Own Tenant) | No |
| `USER_MANAGE` | Yes | Yes (Own Tenant) | No |
| `SLOT_CONFIG` | Yes | Yes (Own Tenant) | Yes |
| `TICKET_RESOLVE` | Yes | No | Yes |
