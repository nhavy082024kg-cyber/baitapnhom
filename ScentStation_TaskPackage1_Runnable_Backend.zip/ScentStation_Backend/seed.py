from app.core.database import Base, engine, SessionLocal
from app.core.security import hash_password
from app.models.models import Tenant, Role, Permission, Account, Brand, Perfume, Machine, PerfumeSlot

def seed_database():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        if db.query(Tenant).first():
            print("Database already seeded.")
            return

        # 1. Permissions
        perm_defs = [
            ("TENANT_MANAGE", "TENANT", "Manage platform tenants"),
            ("BRAND_WRITE", "BRAND", "Create and update brands"),
            ("PERFUME_WRITE", "PERFUME", "Create and update perfumes"),
            ("USER_MANAGE", "USER", "Manage tenant users and roles"),
            ("SLOT_CONFIG", "KIOSK", "Configure kiosk perfume slots"),
            ("TICKET_RESOLVE", "MAINTENANCE", "Resolve maintenance tickets"),
        ]
        perms = {}
        for code, mod, desc in perm_defs:
            p = Permission(permission_code=code, module=mod, description=desc)
            db.add(p)
            perms[code] = p

        # 2. Roles
        r_super = Role(role_name="SUPER_ADMIN", description="Platform Super Administrator")
        r_super.permissions = list(perms.values())

        r_manager = Role(role_name="BRAND_MANAGER", description="Tenant Brand Manager")
        r_manager.permissions = [perms["BRAND_WRITE"], perms["PERFUME_WRITE"], perms["USER_MANAGE"], perms["SLOT_CONFIG"]]

        r_tech = Role(role_name="TECHNICIAN", description="Field Maintenance Technician")
        r_tech.permissions = [perms["SLOT_CONFIG"], perms["TICKET_RESOLVE"]]

        db.add_all([r_super, r_manager, r_tech])
        db.flush()

        # 3. Tenants
        t_platform = Tenant(tenant_code="PLATFORM_HQ", tenant_name="ScentStation Platform HQ")
        t_chanel = Tenant(tenant_code="CHANEL_OPS", tenant_name="Chanel Vietnam Operator")
        t_lvmh = Tenant(tenant_code="LVMH_OPS", tenant_name="Dior & YSL Operator")
        t_luxury = Tenant(tenant_code="LUXURY_OPS", tenant_name="Gucci & Hermes Operator")
        db.add_all([t_platform, t_chanel, t_lvmh, t_luxury])
        db.flush()

        # 4. Accounts
        u_super = Account(
            tenant_id=t_platform.tenant_id, email="superadmin@scentstation.io",
            password_hash=hash_password("Admin123!"), full_name="System Super Admin", is_super_admin=True
        )
        u_super.roles.append(r_super)

        u_chanel_mgr = Account(
            tenant_id=t_chanel.tenant_id, email="manager@chanel.com",
            password_hash=hash_password("Pass123!"), full_name="Chanel Brand Manager"
        )
        u_chanel_mgr.roles.append(r_manager)

        u_chanel_tech = Account(
            tenant_id=t_chanel.tenant_id, email="tech@chanel.com",
            password_hash=hash_password("Pass123!"), full_name="Chanel Field Tech"
        )
        u_chanel_tech.roles.append(r_tech)

        u_lvmh_mgr = Account(
            tenant_id=t_lvmh.tenant_id, email="manager@lvmh.com",
            password_hash=hash_password("Pass123!"), full_name="LVMH Brand Manager"
        )
        u_lvmh_mgr.roles.append(r_manager)

        u_lux_mgr = Account(
            tenant_id=t_luxury.tenant_id, email="manager@luxury.com",
            password_hash=hash_password("Pass123!"), full_name="Luxury Group Manager"
        )
        u_lux_mgr.roles.append(r_manager)

        db.add_all([u_super, u_chanel_mgr, u_chanel_tech, u_lvmh_mgr, u_lux_mgr])
        db.flush()

        # 5. Brands (5 luxury brands)
        b_chanel = Brand(tenant_id=t_chanel.tenant_id, brand_name="Chanel")
        b_ysl = Brand(tenant_id=t_lvmh.tenant_id, brand_name="YSL")
        b_dior = Brand(tenant_id=t_lvmh.tenant_id, brand_name="Dior")
        b_gucci = Brand(tenant_id=t_luxury.tenant_id, brand_name="Gucci")
        b_hermes = Brand(tenant_id=t_luxury.tenant_id, brand_name="Hermes")
        db.add_all([b_chanel, b_ysl, b_dior, b_gucci, b_hermes])
        db.flush()

        # 6. Sample Perfumes
        perfumes = [
            Perfume(tenant_id=t_chanel.tenant_id, brand_id=b_chanel.brand_id, product_code="CH-BLEU-100", perfume_name="Bleu de Chanel EDP", price_per_spray=3.00),
            Perfume(tenant_id=t_lvmh.tenant_id, brand_id=b_ysl.brand_id, product_code="YSL-LIBRE-90", perfume_name="YSL Libre EDP", price_per_spray=2.80),
            Perfume(tenant_id=t_lvmh.tenant_id, brand_id=b_dior.brand_id, product_code="DR-SAUV-100", perfume_name="Dior Sauvage Elixir", price_per_spray=3.20),
            Perfume(tenant_id=t_luxury.tenant_id, brand_id=b_gucci.brand_id, product_code="GC-BLOOM-100", perfume_name="Gucci Bloom EDP", price_per_spray=2.70),
            Perfume(tenant_id=t_luxury.tenant_id, brand_id=b_hermes.brand_id, product_code="HM-TERRE-100", perfume_name="Terre d'Hermes EDT", price_per_spray=3.10),
        ]
        db.add_all(perfumes)
        db.flush()

        # 7. Prototype 5-Slot Kiosk Machine
        kiosk = Machine(tenant_id=t_platform.tenant_id, machine_code="KIOSK-HCM-01", location="Saigon Centre Mall")
        db.add(kiosk)
        db.flush()

        brand_perfume_pairs = [
            (1, b_chanel, perfumes[0]),
            (2, b_ysl, perfumes[1]),
            (3, b_dior, perfumes[2]),
            (4, b_gucci, perfumes[3]),
            (5, b_hermes, perfumes[4]),
        ]
        for slot_num, br, pf in brand_perfume_pairs:
            db.add(PerfumeSlot(machine_id=kiosk.machine_id, slot_number=slot_num, brand_id=br.brand_id, perfume_id=pf.perfume_id))

        db.commit()
        print("Seeded ScentStation database successfully!")
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()
