from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, ConfigDict, EmailStr, Field

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    tenant_id: int
    roles: List[str]
    permissions: List[str]

class UserProfile(BaseModel):
    account_id: int
    tenant_id: int
    email: str
    full_name: str
    is_super_admin: bool
    status: str
    roles: List[str]
    permissions: List[str]

class TenantCreate(BaseModel):
    tenant_code: str = Field(..., min_length=2, max_length=50)
    tenant_name: str = Field(..., min_length=2, max_length=150)

class TenantOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    tenant_id: int
    tenant_code: str
    tenant_name: str
    status: str
    created_at: datetime

class BrandCreate(BaseModel):
    brand_name: str = Field(..., min_length=2, max_length=100)

class BrandOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    brand_id: int
    tenant_id: int
    brand_name: str
    status: str

class PerfumeCreate(BaseModel):
    product_code: str = Field(..., min_length=2, max_length=50)
    perfume_name: str = Field(..., min_length=2, max_length=150)
    price_per_spray: float = Field(default=2.50, gt=0)

class PerfumeUpdate(BaseModel):
    perfume_name: Optional[str] = None
    price_per_spray: Optional[float] = Field(default=None, gt=0)
    status: Optional[str] = None

class PerfumeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    perfume_id: int
    tenant_id: int
    brand_id: int
    product_code: str
    perfume_name: str
    price_per_spray: float
    status: str

class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=6)
    full_name: str = Field(..., min_length=2, max_length=100)
    role_name: str = Field(default="BRAND_MANAGER")

class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    account_id: int
    tenant_id: int
    email: str
    full_name: str
    is_super_admin: bool
    status: str

class RoleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    role_id: int
    role_name: str
    description: str

class AssignPermissionsRequest(BaseModel):
    permission_codes: List[str]
