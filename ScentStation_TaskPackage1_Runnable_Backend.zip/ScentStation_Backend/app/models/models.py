from datetime import datetime, timezone
from sqlalchemy import (
    Column, Integer, String, Boolean, ForeignKey, Numeric, DateTime,
    Table, CheckConstraint, UniqueConstraint
)
from sqlalchemy.orm import relationship
from app.core.database import Base

def utcnow():
    return datetime.now(timezone.utc)

# Many-to-Many: Account <-> Role
account_roles = Table(
    "account_roles",
    Base.metadata,
    Column("account_id", Integer, ForeignKey("accounts.account_id", ondelete="CASCADE"), primary_key=True),
    Column("role_id", Integer, ForeignKey("roles.role_id", ondelete="CASCADE"), primary_key=True),
)

# Many-to-Many: Role <-> Permission
role_permissions = Table(
    "role_permissions",
    Base.metadata,
    Column("role_id", Integer, ForeignKey("roles.role_id", ondelete="CASCADE"), primary_key=True),
    Column("permission_id", Integer, ForeignKey("permissions.permission_id", ondelete="CASCADE"), primary_key=True),
)

class Tenant(Base):
    __tablename__ = "tenants"

    tenant_id = Column(Integer, primary_key=True, index=True)
    tenant_code = Column(String(50), unique=True, nullable=False, index=True)
    tenant_name = Column(String(150), nullable=False)
    status = Column(String(20), default="ACTIVE", nullable=False)
    created_at = Column(DateTime(timezone=True), default=utcnow)

    accounts = relationship("Account", back_populates="tenant")
    brands = relationship("Brand", back_populates="tenant")
    machines = relationship("Machine", back_populates="tenant")

class Role(Base):
    __tablename__ = "roles"

    role_id = Column(Integer, primary_key=True, index=True)
    role_name = Column(String(50), unique=True, nullable=False)
    description = Column(String(255), default="")

    permissions = relationship("Permission", secondary=role_permissions, back_populates="roles")
    accounts = relationship("Account", secondary=account_roles, back_populates="roles")

class Permission(Base):
    __tablename__ = "permissions"

    permission_id = Column(Integer, primary_key=True, index=True)
    permission_code = Column(String(60), unique=True, nullable=False)
    module = Column(String(50), nullable=False)
    description = Column(String(255), default="")

    roles = relationship("Role", secondary=role_permissions, back_populates="permissions")

class Account(Base):
    __tablename__ = "accounts"

    account_id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(Integer, ForeignKey("tenants.tenant_id"), nullable=False, index=True)
    email = Column(String(150), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(100), nullable=False)
    is_super_admin = Column(Boolean, default=False, nullable=False)
    status = Column(String(20), default="ACTIVE", nullable=False)
    created_at = Column(DateTime(timezone=True), default=utcnow)

    tenant = relationship("Tenant", back_populates="accounts")
    roles = relationship("Role", secondary=account_roles, back_populates="accounts")

    @property
    def permission_codes(self) -> set[str]:
        codes: set[str] = set()
        for role in self.roles:
            for perm in role.permissions:
                codes.add(perm.permission_code)
        return codes

class Brand(Base):
    __tablename__ = "brands"

    brand_id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(Integer, ForeignKey("tenants.tenant_id"), nullable=False, index=True)
    brand_name = Column(String(100), nullable=False)
    status = Column(String(20), default="ACTIVE", nullable=False)
    created_at = Column(DateTime(timezone=True), default=utcnow)

    tenant = relationship("Tenant", back_populates="brands")
    perfumes = relationship("Perfume", back_populates="brand")

class Perfume(Base):
    __tablename__ = "perfumes"

    perfume_id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(Integer, ForeignKey("tenants.tenant_id"), nullable=False, index=True)
    brand_id = Column(Integer, ForeignKey("brands.brand_id"), nullable=False, index=True)
    product_code = Column(String(50), unique=True, nullable=False)
    perfume_name = Column(String(150), nullable=False)
    price_per_spray = Column(Numeric(10, 2), default=2.50, nullable=False)
    status = Column(String(20), default="ACTIVE", nullable=False)
    created_at = Column(DateTime(timezone=True), default=utcnow)

    brand = relationship("Brand", back_populates="perfumes")

class Machine(Base):
    __tablename__ = "machines"

    machine_id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(Integer, ForeignKey("tenants.tenant_id"), nullable=False, index=True)
    machine_code = Column(String(50), unique=True, nullable=False)
    location = Column(String(200), default="")
    status = Column(String(20), default="ONLINE", nullable=False)
    last_seen_at = Column(DateTime(timezone=True), default=utcnow)

    tenant = relationship("Tenant", back_populates="machines")
    slots = relationship("PerfumeSlot", back_populates="machine")

class PerfumeSlot(Base):
    __tablename__ = "perfume_slots"
    __table_args__ = (
        CheckConstraint("slot_number >= 1 AND slot_number <= 5", name="ck_slot_number_1_to_5"),
        UniqueConstraint("machine_id", "slot_number", name="uq_machine_slot_number"),
    )

    slot_id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(Integer, ForeignKey("machines.machine_id"), nullable=False, index=True)
    slot_number = Column(Integer, nullable=False)
    brand_id = Column(Integer, ForeignKey("brands.brand_id"), nullable=True)
    perfume_id = Column(Integer, ForeignKey("perfumes.perfume_id"), nullable=True)
    remaining_ml = Column(Numeric(10, 2), default=100.00, nullable=False)
    status = Column(String(20), default="ACTIVE", nullable=False)

    machine = relationship("Machine", back_populates="slots")

class AuditLog(Base):
    __tablename__ = "audit_logs"

    log_id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(Integer, ForeignKey("tenants.tenant_id"), nullable=False, index=True)
    actor_id = Column(Integer, ForeignKey("accounts.account_id"), nullable=False)
    action = Column(String(100), nullable=False)
    entity = Column(String(100), nullable=False)
    details = Column(String(500), default="")
    created_at = Column(DateTime(timezone=True), default=utcnow)
