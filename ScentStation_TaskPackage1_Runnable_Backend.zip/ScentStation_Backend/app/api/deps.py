from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
import jwt
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.security import decode_access_token
from app.models.models import Account, AuditLog

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")

def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> Account:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = decode_access_token(token)
        email: str | None = payload.get("sub")
        if email is None:
            raise credentials_exception
    except jwt.PyJWTError:
        raise credentials_exception

    user = db.query(Account).filter(Account.email == email, Account.status == "ACTIVE").first()
    if user is None:
        raise credentials_exception
    return user

def require_super_admin(current_user: Account = Depends(get_current_user)) -> Account:
    if not current_user.is_super_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Super Admin privileges required",
        )
    return current_user

def require_permission(permission_code: str):
    def _checker(current_user: Account = Depends(get_current_user)) -> Account:
        if current_user.is_super_admin:
            return current_user
        if permission_code not in current_user.permission_codes:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Missing required permission: {permission_code}",
            )
        return current_user
    return _checker

def record_audit(db: Session, user: Account, action: str, entity: str, details: str = "") -> None:
    log = AuditLog(
        tenant_id=user.tenant_id,
        actor_id=user.account_id,
        action=action,
        entity=entity,
        details=details,
    )
    db.add(log)
