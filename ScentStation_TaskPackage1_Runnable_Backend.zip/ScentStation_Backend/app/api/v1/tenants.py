from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.models import Account, Tenant
from app.schemas.schemas import TenantCreate, TenantOut
from app.api.deps import require_super_admin, record_audit

router = APIRouter(prefix="/api/v1/tenants", tags=["Tenant Administration"])

@router.get("", response_model=List[TenantOut])
def list_tenants(
    _: Account = Depends(require_super_admin),
    db: Session = Depends(get_db),
):
    return db.query(Tenant).all()

@router.post("", response_model=TenantOut, status_code=201)
def create_tenant(
    payload: TenantCreate,
    current_user: Account = Depends(require_super_admin),
    db: Session = Depends(get_db),
):
    if db.query(Tenant).filter(Tenant.tenant_code == payload.tenant_code).first():
        raise HTTPException(status_code=400, detail="Tenant code already exists")
    tenant = Tenant(tenant_code=payload.tenant_code, tenant_name=payload.tenant_name)
    db.add(tenant)
    db.flush()
    record_audit(db, current_user, "CREATE_TENANT", f"Tenant:{tenant.tenant_id}", payload.tenant_code)
    db.commit()
    db.refresh(tenant)
    return tenant
