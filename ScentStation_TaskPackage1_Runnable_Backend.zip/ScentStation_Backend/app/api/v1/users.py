from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.security import hash_password
from app.models.models import Account, Role, Permission
from app.schemas.schemas import UserCreate, UserOut, RoleOut, AssignPermissionsRequest
from app.api.deps import require_permission, require_super_admin, record_audit

router = APIRouter(prefix="/api/v1", tags=["Users & RBAC"])

@router.get("/users", response_model=List[UserOut])
def list_tenant_users(
    current_user: Account = Depends(require_permission("USER_MANAGE")),
    db: Session = Depends(get_db),
):
    return db.query(Account).filter(Account.tenant_id == current_user.tenant_id).all()

@router.post("/users", response_model=UserOut, status_code=201)
def create_tenant_user(
    payload: UserCreate,
    current_user: Account = Depends(require_permission("USER_MANAGE")),
    db: Session = Depends(get_db),
):
    if db.query(Account).filter(Account.email == payload.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")

    role = db.query(Role).filter(Role.role_name == payload.role_name).first()
    if not role:
        raise HTTPException(status_code=400, detail=f"Role '{payload.role_name}' not found")
    if role.role_name == "SUPER_ADMIN" and not current_user.is_super_admin:
        raise HTTPException(status_code=403, detail="Cannot assign SUPER_ADMIN role")

    user = Account(
        tenant_id=current_user.tenant_id,
        email=payload.email,
        password_hash=hash_password(payload.password),
        full_name=payload.full_name,
        is_super_admin=False,
    )
    user.roles.append(role)
    db.add(user)
    db.flush()
    record_audit(db, current_user, "CREATE_USER", f"Account:{user.account_id}", payload.email)
    db.commit()
    db.refresh(user)
    return user

@router.get("/roles", response_model=List[RoleOut])
def list_roles(
    _: Account = Depends(require_permission("USER_MANAGE")),
    db: Session = Depends(get_db),
):
    return db.query(Role).all()

@router.put("/roles/{role_id}/permissions", response_model=RoleOut)
def assign_role_permissions(
    role_id: int,
    payload: AssignPermissionsRequest,
    current_user: Account = Depends(require_super_admin),
    db: Session = Depends(get_db),
):
    role = db.query(Role).filter(Role.role_id == role_id).first()
    if not role:
        raise HTTPException(status_code=404, detail="Role not found")

    perms = db.query(Permission).filter(Permission.permission_code.in_(payload.permission_codes)).all()
    role.permissions = perms
    record_audit(db, current_user, "ASSIGN_PERMISSIONS", f"Role:{role.role_id}", ",".join(payload.permission_codes))
    db.commit()
    db.refresh(role)
    return role
