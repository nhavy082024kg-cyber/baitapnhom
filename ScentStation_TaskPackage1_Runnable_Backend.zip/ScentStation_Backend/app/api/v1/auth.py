from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.security import verify_password, create_access_token
from app.models.models import Account
from app.schemas.schemas import TokenResponse, UserProfile
from app.api.deps import get_current_user

router = APIRouter(prefix="/api/v1/auth", tags=["Authentication"])

@router.post("/login", response_model=TokenResponse)
def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db),
):
    user = db.query(Account).filter(Account.email == form_data.username).first()
    if not user or user.status != "ACTIVE" or not verify_password(form_data.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
        )

    roles = [r.role_name for r in user.roles]
    perms = sorted(list(user.permission_codes))
    token = create_access_token(
        {
            "sub": user.email,
            "account_id": user.account_id,
            "tenant_id": user.tenant_id,
            "is_super_admin": user.is_super_admin,
            "roles": roles,
            "permissions": perms,
        }
    )
    return TokenResponse(
        access_token=token,
        tenant_id=user.tenant_id,
        roles=roles,
        permissions=perms,
    )

@router.get("/me", response_model=UserProfile)
def get_me(current_user: Account = Depends(get_current_user)):
    return UserProfile(
        account_id=current_user.account_id,
        tenant_id=current_user.tenant_id,
        email=current_user.email,
        full_name=current_user.full_name,
        is_super_admin=current_user.is_super_admin,
        status=current_user.status,
        roles=[r.role_name for r in current_user.roles],
        permissions=sorted(list(current_user.permission_codes)),
    )
