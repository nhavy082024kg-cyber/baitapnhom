from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.models import Account, Brand, Perfume
from app.schemas.schemas import BrandCreate, BrandOut, PerfumeCreate, PerfumeUpdate, PerfumeOut
from app.api.deps import get_current_user, require_permission, record_audit

router = APIRouter(prefix="/api/v1", tags=["Brand & Perfume Administration"])

@router.get("/brands", response_model=List[BrandOut])
def list_brands(
    current_user: Account = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    # Strict tenant isolation
    return db.query(Brand).filter(Brand.tenant_id == current_user.tenant_id).all()

@router.post("/brands", response_model=BrandOut, status_code=201)
def create_brand(
    payload: BrandCreate,
    current_user: Account = Depends(require_permission("BRAND_WRITE")),
    db: Session = Depends(get_db),
):
    brand = Brand(tenant_id=current_user.tenant_id, brand_name=payload.brand_name)
    db.add(brand)
    db.flush()
    record_audit(db, current_user, "CREATE_BRAND", f"Brand:{brand.brand_id}", payload.brand_name)
    db.commit()
    db.refresh(brand)
    return brand

@router.get("/perfumes", response_model=List[PerfumeOut])
def list_perfumes(
    current_user: Account = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    return db.query(Perfume).filter(Perfume.tenant_id == current_user.tenant_id).all()

@router.post("/brands/{brand_id}/perfumes", response_model=PerfumeOut, status_code=201)
def add_perfume(
    brand_id: int,
    payload: PerfumeCreate,
    current_user: Account = Depends(require_permission("PERFUME_WRITE")),
    db: Session = Depends(get_db),
):
    brand = (
        db.query(Brand)
        .filter(Brand.brand_id == brand_id, Brand.tenant_id == current_user.tenant_id)
        .first()
    )
    if not brand:
        raise HTTPException(status_code=404, detail="Brand not found in your tenant scope")

    if db.query(Perfume).filter(Perfume.product_code == payload.product_code).first():
        raise HTTPException(status_code=400, detail="Product code already exists")

    perfume = Perfume(
        tenant_id=current_user.tenant_id,
        brand_id=brand.brand_id,
        product_code=payload.product_code,
        perfume_name=payload.perfume_name,
        price_per_spray=payload.price_per_spray,
    )
    db.add(perfume)
    db.flush()
    record_audit(db, current_user, "CREATE_PERFUME", f"Perfume:{perfume.perfume_id}", payload.product_code)
    db.commit()
    db.refresh(perfume)
    return perfume

@router.patch("/perfumes/{perfume_id}", response_model=PerfumeOut)
def update_perfume(
    perfume_id: int,
    payload: PerfumeUpdate,
    current_user: Account = Depends(require_permission("PERFUME_WRITE")),
    db: Session = Depends(get_db),
):
    perfume = (
        db.query(Perfume)
        .filter(Perfume.perfume_id == perfume_id, Perfume.tenant_id == current_user.tenant_id)
        .first()
    )
    if not perfume:
        raise HTTPException(status_code=404, detail="Perfume not found in your tenant scope")

    if payload.perfume_name is not None:
        perfume.perfume_name = payload.perfume_name
    if payload.price_per_spray is not None:
        perfume.price_per_spray = payload.price_per_spray
    if payload.status is not None:
        perfume.status = payload.status

    record_audit(db, current_user, "UPDATE_PERFUME", f"Perfume:{perfume.perfume_id}")
    db.commit()
    db.refresh(perfume)
    return perfume
