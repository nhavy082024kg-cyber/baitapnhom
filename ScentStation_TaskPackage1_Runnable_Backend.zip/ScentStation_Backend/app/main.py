from contextlib import asynccontextmanager
from fastapi import FastAPI
from app.core.config import settings
from app.api.v1 import auth, tenants, brands, users
from seed import seed_database

@asynccontextmanager
async def lifespan(app: FastAPI):
    seed_database()
    yield

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="Multi-Tenant IoT Perfume Experience Platform (Chanel, YSL, Dior, Gucci, Hermès)",
    lifespan=lifespan,
)

app.include_router(auth.router)
app.include_router(tenants.router)
app.include_router(brands.router)
app.include_router(users.router)

@app.get("/health", tags=["System"])
def health_check():
    return {"status": "ok", "service": settings.PROJECT_NAME}
